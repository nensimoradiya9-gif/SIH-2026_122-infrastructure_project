from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from database import Base, engine
from models.user import User
from routes.auth import router as auth_router
from fastapi import Depends
from dependencies import get_current_user

Base.metadata.create_all(bind=engine)

app = FastAPI(title="ProjectSync AI Backend")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth_router)

@app.get("/api/protected")
def protected_route(current_user=Depends(get_current_user)):
    return {
        "message": "You are authenticated!",
        "user": current_user
    }


@app.get("/")
def home():
    return {
        "message": "ProjectSync AI Backend is running"
    }


@app.get("/api/health")
def health():
    return {
        "status": "ok"
    }