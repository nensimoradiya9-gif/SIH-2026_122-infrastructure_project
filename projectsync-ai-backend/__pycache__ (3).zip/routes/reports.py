from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from database import SessionLocal
from models.project import Project
from models.activity import Activity
from models.daily_report import DailyReport

router = APIRouter(
    prefix="/api/reports",
    tags=["Reports"]
)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@router.get("/")
def get_reports(db: Session = Depends(get_db)):

    projects = db.query(Project).all()
    activities = db.query(Activity).all()
    daily_reports = db.query(DailyReport).all()

    return {
        "total_projects": len(projects),
        "total_activities": len(activities),
        "total_daily_reports": len(daily_reports),
        "projects": projects,
        "activities": activities,
        "daily_reports": daily_reports
    }


@router.get("/project/{project_id}")
def get_project_report(
    project_id: int,
    db: Session = Depends(get_db)
):

    project = db.query(Project).filter(
        Project.id == project_id
    ).first()

    if not project:
        raise HTTPException(
            status_code=404,
            detail="Project not found"
        )

    activities = db.query(Activity).filter(
        Activity.project_id == project_id
    ).all()

    daily_reports = db.query(DailyReport).filter(
        DailyReport.project_id == project_id
    ).all()

    return {
        "project": project,
        "activities": activities,
        "daily_reports": daily_reports
    }