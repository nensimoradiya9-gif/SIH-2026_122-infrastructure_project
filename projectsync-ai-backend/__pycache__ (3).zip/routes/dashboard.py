from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from database import SessionLocal
from models.project import Project
from models.activity import Activity
from models.daily_report import DailyReport

router = APIRouter(
    prefix="/api/dashboard",
    tags=["Dashboard"]
)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.get("/")
def get_dashboard(db: Session = Depends(get_db)):

    total_projects = db.query(Project).count()
    total_activities = db.query(Activity).count()
    total_reports = db.query(DailyReport).count()

    pending_activities = (
        db.query(Activity)
        .filter(Activity.status == "pending")
        .count()
    )

    completed_activities = (
        db.query(Activity)
        .filter(Activity.status == "completed")
        .count()
    )

    return {
        "total_projects": total_projects,
        "total_activities": total_activities,
        "total_reports": total_reports,
        "pending_activities": pending_activities,
        "completed_activities": completed_activities
    }