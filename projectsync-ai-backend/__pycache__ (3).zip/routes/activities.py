from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional
from datetime import date

from database import SessionLocal
from models.activity import Activity
from models.project import Project


router = APIRouter(
    prefix="/api/activities",
    tags=["Activities"]
)


def get_db():
    db = SessionLocal()

    try:
        yield db
    finally:
        db.close()


class ActivityRequest(BaseModel):
    project_id: int
    title: str
    description: Optional[str] = None
    activity_date: date
    status: Optional[str] = "pending"
    assigned_to: Optional[str] = None
    priority: Optional[str] = "medium"


@router.post("/")
def create_activity(
    data: ActivityRequest,
    db: Session = Depends(get_db)
):
    project = db.query(Project).filter(
        Project.id == data.project_id
    ).first()

    if not project:
        raise HTTPException(
            status_code=404,
            detail="Project not found"
        )

    activity = Activity(
        project_id=data.project_id,
        title=data.title,
        description=data.description,
        activity_date=data.activity_date,
        status=data.status,
        assigned_to=data.assigned_to,
        priority=data.priority
    )

    db.add(activity)
    db.commit()
    db.refresh(activity)

    return activity


@router.get("/")
def get_activities(
    db: Session = Depends(get_db)
):
    return db.query(Activity).all()


@router.get("/{activity_id}")
def get_activity(
    activity_id: int,
    db: Session = Depends(get_db)
):
    activity = db.query(Activity).filter(
        Activity.id == activity_id
    ).first()

    if not activity:
        raise HTTPException(
            status_code=404,
            detail="Activity not found"
        )

    return activity


@router.put("/{activity_id}")
def update_activity(
    activity_id: int,
    data: ActivityRequest,
    db: Session = Depends(get_db)
):
    activity = db.query(Activity).filter(
        Activity.id == activity_id
    ).first()

    if not activity:
        raise HTTPException(
            status_code=404,
            detail="Activity not found"
        )

    project = db.query(Project).filter(
        Project.id == data.project_id
    ).first()

    if not project:
        raise HTTPException(
            status_code=404,
            detail="Project not found"
        )

    activity.project_id = data.project_id
    activity.title = data.title
    activity.description = data.description
    activity.activity_date = data.activity_date
    activity.status = data.status
    activity.assigned_to = data.assigned_to
    activity.priority = data.priority

    db.commit()
    db.refresh(activity)

    return activity


@router.delete("/{activity_id}")
def delete_activity(
    activity_id: int,
    db: Session = Depends(get_db)
):
    activity = db.query(Activity).filter(
        Activity.id == activity_id
    ).first()

    if not activity:
        raise HTTPException(
            status_code=404,
            detail="Activity not found"
        )

    db.delete(activity)
    db.commit()

    return {
        "message": "Activity deleted successfully"
    }