from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional

from database import SessionLocal
from models.knowledge import Knowledge
from models.project import Project

router = APIRouter(
    prefix="/api/knowledge",
    tags=["Knowledge"]
)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


class KnowledgeRequest(BaseModel):
    project_id: int
    title: str
    content: str
    category: Optional[str] = None


@router.post("/")
def create_knowledge(
    data: KnowledgeRequest,
    db: Session = Depends(get_db)
):
    project = db.query(Project).filter(
        Project.id == data.project_id
    ).first()

    if not project:
        raise HTTPException(
            status_code=404,
            detail="Project not found"
        )

    knowledge = Knowledge(
        project_id=data.project_id,
        title=data.title,
        content=data.content,
        category=data.category
    )

    db.add(knowledge)
    db.commit()
    db.refresh(knowledge)

    return knowledge


@router.get("/")
def get_knowledge(db: Session = Depends(get_db)):
    return db.query(Knowledge).all()


@router.get("/{knowledge_id}")
def get_knowledge_item(
    knowledge_id: int,
    db: Session = Depends(get_db)
):
    knowledge = db.query(Knowledge).filter(
        Knowledge.id == knowledge_id
    ).first()

    if not knowledge:
        raise HTTPException(
            status_code=404,
            detail="Knowledge not found"
        )

    return knowledge


@router.delete("/{knowledge_id}")
def delete_knowledge(
    knowledge_id: int,
    db: Session = Depends(get_db)
):
    knowledge = db.query(Knowledge).filter(
        Knowledge.id == knowledge_id
    ).first()

    if not knowledge:
        raise HTTPException(
            status_code=404,
            detail="Knowledge not found"
        )

    db.delete(knowledge)
    db.commit()

    return {
        "message": "Knowledge deleted successfully"
    }


@router.get("/search/{keyword}")
def search_knowledge(
    keyword: str,
    db: Session = Depends(get_db)
):
    results = db.query(Knowledge).filter(
        Knowledge.title.ilike(f"%{keyword}%") |
        Knowledge.content.ilike(f"%{keyword}%")
    ).all()

    return results