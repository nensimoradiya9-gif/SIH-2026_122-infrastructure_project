from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from database import SessionLocal
from models.activity import Activity

router = APIRouter(
    prefix="/api/alerts",
    tags=["Alerts"]
)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@router.get("/")
def get_alerts(db: Session = Depends(get_db)):

    pending_activities = (
        db.query(Activity)
        .filter(Activity.status == "pending")
        .all()
    )

    high_priority_activities = (
        db.query(Activity)
        .filter(Activity.priority == "high")
        .all()
    )

    alerts = []

    for activity in pending_activities:
        alerts.append({
            "type": "pending",
            "activity_id": activity.id,
            "title": activity.title,
            "message": "Activity is still pending"
        })

    for activity in high_priority_activities:
        alerts.append({
            "type": "high_priority",
            "activity_id": activity.id,
            "title": activity.title,
            "message": "High priority activity"
        })

    return {
        "total_alerts": len(alerts),
        "alerts": alerts
    }